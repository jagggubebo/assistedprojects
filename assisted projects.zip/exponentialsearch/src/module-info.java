module exponentialsearch {
}