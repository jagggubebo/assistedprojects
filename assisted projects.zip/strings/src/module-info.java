module strings {
}