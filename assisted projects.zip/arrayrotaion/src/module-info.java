module arrayrotaion {
}