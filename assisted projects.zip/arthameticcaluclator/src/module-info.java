module arthameticcaluclator {
}