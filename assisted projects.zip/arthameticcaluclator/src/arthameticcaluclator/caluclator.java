package arthameticcaluclator;

public class caluclator {

	public static void main(String[] args) {
		
		int number1=15,number2=3;
		int sum = number1+number2;
		System.out.println("Sum is:"+sum);
		int dif = number1-number2;
		System.out.println("Difference is:"+dif);
		int mul = number1*number2;
		System.out.println("Multiplied value is:"+mul);
		int div = number1/number2;
		System.out.println("Quotient is :"+div);
		int rem = number1%number2;
		System.out.println("Remainder is:"+rem);		
		
		


	}

}
