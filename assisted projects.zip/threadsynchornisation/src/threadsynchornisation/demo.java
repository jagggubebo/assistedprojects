package threadsynchornisation;

public class demo {

}
