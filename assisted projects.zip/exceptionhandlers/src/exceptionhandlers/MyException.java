package exceptionhandlers;

public class MyException {

}
