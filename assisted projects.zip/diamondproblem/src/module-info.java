module diamondproblem {
}